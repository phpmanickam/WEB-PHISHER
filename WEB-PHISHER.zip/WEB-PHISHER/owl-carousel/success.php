<?php 
//gtbank//
$site = 'https://www.paypal.com/';
header('Location:'.$site);

?>`
