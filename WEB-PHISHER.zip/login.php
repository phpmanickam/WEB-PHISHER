<?php
if($_POST['pass'] === "WEB-PHISHER"){
 header("Location: home.html"); 
 }
 else{
  header("Location: index.html"); 
 }
?>